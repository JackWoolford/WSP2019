<!doctype html>
<html>
    <h1> Welcome to Admin Index</h1>
    <a href = "addPart.php"> Add Parts </a>
    <br>
    <a href = "changeParts.php"> Update Parts </a>
    <br>
    <a href = "logout.php"> Logout </a>
</html>